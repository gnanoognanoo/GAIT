const productName = 'KINETIQ';
